These data files came from Michael Friendly's [Minard gallery](http://www.datavis.ca/gallery/minard/ggplot2/ggplot2-minard-gallery.zip).

